//khancock lab0
//

#include <stdio.h>

//a simple test of turing

int main(int argc, char**argv) {
	if(argc - 1 == 1) {
		printf("I like %s!", argv[1]);
	}
	else {
		printf("What do you like?");
	}
	return 0;
}
